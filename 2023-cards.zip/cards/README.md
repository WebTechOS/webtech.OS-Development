# Cards 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/PoJapGX](https://codepen.io/havardob/pen/PoJapGX).

Recreation of this Dribbble shot designed by the talented Vishnu Prasad: https://dribbble.com/shots/11522673-Landing-Page-Components 